@extends('layout')
@section('title','Dashboard')
@section('body')

<style type="text/css">
	.card
  {
    width: 50%;
    text-align: center;
    align-items: center;
  }
  label
  {
    color: white;
  }
</style>


<div class="container">
  
  <div class="card bg-danger mt-5">
    <br>
    <label><h2>Pilih Kontingen</h2></label>
    <form action="/ktg" method="post"> @csrf
    <select class ="form-control mt-5 mb-5" name="id_asal">
      @foreach( $ktg as $ktg )
      <option value="{{ $ktg->id }}"> {{ $ktg->asal }}</option>
      @endforeach
    </select>
    <button class="btn btn-warning">Pilih</button>
    </form>
    <br><br>
  </div>

</div>

<div class="container mt-5">

<div class="card bg-success"><br>
<label><h3>Pilih Bidang Lomba</h3></label>
<form action="{{ route('dsh.store') }}" method="post"> @csrf
<select class="form-control mt-5" name="id_bl">
  @foreach($bl as $bl)
  <option value="{{ $bl->id }}">{{ $bl->nama }}</option>
  @endforeach
</select>
<button class="btn btn-primary mt-5 mb-5">Pilih</button>
</form>
</div>



</div>


@if($error = Session::get('gagal'))
<h1>{{ $error }}</h1>
@endif


@endsection