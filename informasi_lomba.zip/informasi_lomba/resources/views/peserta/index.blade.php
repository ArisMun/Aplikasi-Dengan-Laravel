@extends('layout')
@section('title','Peserta')
@section('body')

<style type="text/css">
	.table
	{
		text-align: center;
	}
</style>


<div class="container mt-5">
<form action="{{ route('peserta.store') }}" method="post"> @csrf
<label>Bidang Lomba</label>
<select name="id_bl">
  @foreach($bl as $bl)
  <option value="{{ $bl->id }}">{{ $bl->nama }}</option>
  @endforeach
</select>
<br><br>

<label>Asal</label>
<select name="id_asal">
  @foreach($asal as $asal)
  <option value="{{ $asal->id }}">{{ $asal->asal }}</option>
  @endforeach
</select><br><br>


<button class="btn btn-danger mb-5">Daftarkan</button>
<table class="table table-hover table-dark table-striped">
  <thead>
    <tr>
      <th scope="col">Username</th>
      <th scope="col">Bidang Lomba</th>
      <th scope="col">Asal</th>
      <th scope="col">Nilai</th>
      <th scope="col">Pilih</th>
    </tr>
  </thead>
  <tbody>
  	@foreach($user as $k)
    <tr>
      <td>{{ $k->username }}</td>
      <td>{{ $k->id_bl }}</td>
      <td>{{ $k->id_asal }}</td>
      <td><input type="number" readonly value="{{ $k->nilai }}"></td>
      <td>
      	
        <input type="checkbox" name="pilih[]" value="{{ $k->id }}">
      		
      </td>  
      </form>  
  	</tr>
  	@endforeach
  </tbody>
</table>
</div>


@endsection