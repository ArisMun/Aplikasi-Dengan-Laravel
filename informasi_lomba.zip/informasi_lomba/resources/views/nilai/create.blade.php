<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <style type="text/css">
    	.card
    	{
    		text-align: center;
    		align-items: center;
    		margin-right: auto;
    		margin-left: auto;
    		margin-bottom: auto;
    		margin-top: auto;
    		margin-top: 5%;
    	}
    	a
    	{
    		color: white;
    	}
      i
      {
        color: "lime";
      }
      table
      {
        text-align: center;
      }
    </style>

    <title>Tambah Nilai</title>
  </head>
  <body>



<div class="container">
  		
        
		  
<form action="{{ route('nilai.store') }}" method="post"> @csrf

<button class="btn btn-primary mt-4">Tambah</button>
<table class="table table-hover table-dark table-striped mt-5">
  <thead>
    <tr>
      <th scope="col">Username</th>
      <th scope="col">Nilai</th>
    </tr>
  </thead>
  <tbody>
    @foreach($proses as $k)
    <tr>
      <td><input type="number" name="id_user[]" value="{{ $k->id }}" readonly></td>
      <td>
       <input required type="number" name="nilai[]">
      </td>    
    </tr>
    </form>
    @endforeach
  </tbody>
</table>

</div>
   





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
  </body>
</html>