@extends('layout')
@section('title','Penilaian')
@section('body')

<style type="text/css">
	.card
  {
    width: 50%;
    text-align: center;
    align-items: center;
  }
  label
  {
    color: white;
  }
</style>


<div class="container mt-5">

<div class="card bg-success"><br>
<label>Pilih Bidang Lomba</label>
<form action="{{ route('nilai.create') }}">
<select class="form-control mt-5" name="id_bl">
  @foreach($bl as $bl)
  <option value="{{ $bl->id }}">{{ $bl->nama }}</option>
  @endforeach
</select>
<button class="btn btn-primary mt-5 mb-5">Pilih</button>
</form>
</div>
</div>

@if($error = Session::get('gagal'))
<h1>{{ $error }}</h1>
@endif


@endsection