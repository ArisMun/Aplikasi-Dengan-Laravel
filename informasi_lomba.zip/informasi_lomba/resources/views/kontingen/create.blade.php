<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <style type="text/css">
    	.card
    	{
    		text-align: center;
    		align-items: center;
    		margin-right: auto;
    		margin-left: auto;
    		margin-bottom: auto;
    		margin-top: auto;
    		margin-top: 5%;
    	}
    	a
    	{
    		color: white;
    	}
    </style>

    <title>Login</title>
  </head>
  <body>



  	<div class="container">
  		<div class="card text-white bg-primary mb-3" style="width: 50%;">
		  <div class="card-header"><h1><center>Tambah Kontingen</center></h1></div>
		  <div class="card-body">
		  	<form action="{{ route('kontingen.store') }}" method="post"> @csrf
		    <br>
        <label>Asal</label>
        <input type="text" name="asal" placeholder="Asal" class="form-control">
        @if($errors->has('asal'))
            <i>{{ $errors->first('asal') }}</i>
          @endif
        <br>
        <br>
		    <button class="btn btn-warning">Tambah</button>
		    </form>
		    <br>
		  </div>
		</div>
  	</div>
   





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
  </body>
</html>