@extends('layout')
@section('title','Kontingen')
@section('body')

<style type="text/css">
	.table
	{
		text-align: center;
	}
</style>


<div class="container mt-5">
<a href="{{ route('kontingen.create') }}" class="btn btn-primary mb-4">Tambah</a>
<table class="table table-hover table-dark table-striped">
  <thead>
    <tr>
      <th scope="col">Asal</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
  	@foreach($kt as $k)
    <tr>
      <td>{{ $k->asal }}</td>
      <td>
      	<form onsubmit="return confirm('Yakin ?')" action="{{ route('kontingen.destroy',$k->id) }}" method="post">@csrf @method('DELETE')
      		<a href="{{ route('kontingen.edit',$k->id) }}" class="btn btn-primary mb-4">Ubah</a>
      		<button class="btn btn-danger">Hapus</button> 
      	</form>
      </td>    
  	</tr>
  	@endforeach
  </tbody>
</table>
</div>


@endsection