@extends('layout')
@section('title','Bidang Lomba')
@section('body')

<style type="text/css">
	.table
	{
		text-align: center;
	}
</style>


<div class="container mt-5">
<a href="{{ route('bl.create') }}" class="btn btn-primary mb-4">Tambah</a>
<table class="table table-hover table-dark table-striped">
  <thead>
    <tr>
      <th scope="col">Nama Lomba</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
  	@foreach($bl as $b)
    <tr>
      <td>{{ $b->nama }}</td>
      <td>
      	<form onsubmit="return confirm('Yakin ?')" action="{{ route('bl.destroy',$b->id) }}" method="post">@csrf @method('DELETE')
      		<a href="{{ route('bl.edit',$b->id) }}" class="btn btn-primary mb-4">Ubah</a>
      		<button class="btn btn-danger">Hapus</button> 
      	</form>
      </td>    
  	</tr>
  	@endforeach
  </tbody>
</table>
</div>

@if($error = Session::get('gagal'))
<h1>{{ $error }}</h1>
@endif


@endsection