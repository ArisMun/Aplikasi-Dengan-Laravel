<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    <title>@yield('title')</title>
  </head>
  <body>
  


    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><h1>IL LKS Nasional</h1></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link {{ Request::path() == 'home' ? 'active' : '' }}"  aria-current="page" href="/home">Home</a>
        </li>
         <li class="nav-item">
          <a class="nav-link {{ Request::path() == 'bl' ? 'active' : '' }}" aria-current="page" href="{{ route('bl.index') }}">Bidang Lomba</a>
        </li>

        @if(auth()->user()->jabatan == 'admin')
        <li class="nav-item">
          <a class="nav-link {{ Request::path() == 'kontingen' ? 'active' : '' }}" aria-current="page" href="{{ route('kontingen.index') }}">Kontingen</a>
        </li>

        
         <li class="nav-item">
          <a class="nav-link {{ Request::path() == 'peserta' ? 'active' : '' }}" aria-current="page" href="{{ route('peserta.index') }}">Peserta</a>
        </li>


        <li class="nav-item">
          <a class="nav-link {{ Request::path() == 'nilai' ? 'active' : '' }}" aria-current="page" href="{{ route('nilai.index') }}">Penilaian</a>
        </li>


        <li class="nav-item">
          <a class="nav-link {{ Request::path() == 'dsh' ? 'active' : '' }}" aria-current="page" href="{{ route('dsh.index') }}">Dashboard</a>
        </li>

        @endif


         

      </ul>
      <form class="d-flex">
        <a href="/logout" class="text-light">Logout</a>
      </form>
      
    </div>
  </div>
</nav>




    @yield('body')


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
  </body>
</html>