<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\kontingen;
use App\Models\user;
use Illuminate\Support\Facades\DB;

class KontingenController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $kt = DB::table('kontingens')->get();
        return view('kontingen.index',compact('kt'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('kontingen.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $req)
    {
         $this->validate($req,[
            'asal' => 'required|unique:kontingens',
        ]);

        $proses = kontingen::create([
            'asal' => $req->asal,
        ]);

        if ($proses) {
            return redirect()->route('kontingen.index')->with('berhasil_tambah','Data Berhasil Di Tambahkan');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $k = kontingen::findOrFail($id);
        return view('kontingen.edit',compact('k'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $req, $id)
    {
        $kt = kontingen::findOrFail($id);
        $this->validate($req,[
            'asal' => 'required',
        ]);

        if ($kt->asal == $req->asal) {
            return redirect()->route('kontingen.index')->with('berhasil_ubah','Data Berhasil Di Ubah');
        }
        else
        {
            $kt->update([

                'asal' => $req->asal,

            ]);

            if ($kt) {
                    return redirect()->route('kontingen.index')->with('berhasil_ubah','Data Berhasil Di Ubah');
            }

        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
         $proses = kontingen::findOrFail($id)->delete();

        if ($proses) {
            return redirect()->route('kontingen.index')->with('berhasil_hapush','Data Berhasil Di Hapus');
        }
    }
}
