<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use App\Models\registrasi;
use App\Models\penilaian;
use Illuminate\Support\Facades\DB;

class LoginController extends Controller
{
    public function index()
    {
    	if (Auth::check()) {
    		return redirect('/');
    	}
    	return view('login.index');
    }

    public function buat()
    {
        $bl = DB::table('bidang_lomba')->get();
        $asal = DB::table('kontingens')->get();
    	return view('login.create',compact('bl','asal'));
    }

    public function login(Request $req)
    {
    	$this->validate($req,[
    		'username' => 'required',
    		'password' => 'required',
    	]);

    	$data = [
    		'username' => $req->input('username'),
    		'password' => $req->input('password'),
    	];

    	Auth::attempt($data);

    	if (Auth::check()) {
    		return redirect('/home');
    	}
        else
        {
            return redirect('/');
        }
    }

    public function proses_buat(Request $req)
    {
       
    	$this->validate($req,[
    		'username' => 'required',
    		'password' => 'required',
    		'jabatan' => 'required',
    	]);


    	$proses = user::create([
    		'username' => $req->username,
    		'password' => bcrypt($req->password),
            'id_bl' => $req->id_bl,
            'id_asal' => $req->id_asal,
    		'jabatan' => $req->jabatan,
    	]);

    	if ($proses) {
    		return redirect('/');
    	}
    }


    public function home()
    {
    	return view('login.home');
    }

    public function logout()
    {
    	Auth::logout();
    	return redirect('/');
    }

    public function daftar($id)
    {  


        $cek = registrasi::where('id_user','=',auth()->user()->id)->count();

        if ($cek ==0) {

             $proses = registrasi::create([

            'id_user' => auth()->user()->id,
            'id_bl' => $id,
            'status' => 'sudah',

            ]);

            if ($proses) {
                return redirect()->route('bl.index');
            }
           
        }
        else
        {
             return redirect()->route('bl.index')->with('gagal','Anda Sudah Mendaftar');
        }
       
        
    }

    public function ktg(Request $req)
    {
        
       $nilai = user::where('id_asal','=',$req->id_asal)->get();

        return view('dashboard.ktg',compact('nilai'));
    }
}
