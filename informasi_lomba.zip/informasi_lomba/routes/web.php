<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\loginController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//login
Route::get('/',[loginController::class,'index'])->name('login');
Route::get('/buat',[loginController::class,'buat']);
Route::post('/proses_buat',[loginController::class,'proses_buat']);
Route::post('/login',[loginController::class,'login']);
Route::get('/home',[loginController::class,'home'])->middleware('auth');
Route::get('/logout',[loginController::class,'logout']);
Route::get('/daftar/{id}',[loginController::class,'daftar']);
Route::post('/ktg',[loginController::class,'ktg']);


//Bidang Lomba
Route::resource('bl',BidangLombaController::class);


//kontingen
Route::resource('kontingen',KontingenController::class)->middleware('user');


//nilai
Route::resource('nilai',PenilaianController::class)->middleware('user');



//dsh
Route::resource('dsh',DashboardController::class)->middleware('user');


//peserta
Route::resource('peserta',PesertaController::class)->middleware('user');