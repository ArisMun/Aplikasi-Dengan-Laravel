<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <style type="text/css">
    	.card
    	{
    		text-align: center;
    		align-items: center;
    		margin-right: auto;
    		margin-left: auto;
    		margin-bottom: auto;
    		margin-top: auto;
    		margin-top: 5%;
    	}
    	a
    	{
    		color: white;
    	}
      i
      {
        color: "lime";
      }
    </style>

    <title>Buat Akun</title>
  </head>
  <body>



  	<div class="container">
  		<div class="card text-white bg-danger mb-3" style="width: 50%;">
		  <div class="card-header"><h1><center>Buat Akun</center></h1></div>
		  <div class="card-body">
		  	<label>Username</label>
        <form action="/proses_buat" method="post"><?php echo csrf_field(); ?>
		    <input type="text" name="username" placeholder="username" class="form-control">
		    <br>
        <?php if($errors->has('username')): ?>
          <i><?php echo e($errors->first('username')); ?></i>
        <?php endif; ?>
        <br>
		    <label>Password</label>
		    <input type="password" name="password" placeholder="password" class="form-control">
		    <br>
        <?php if($errors->has('password')): ?>
          <i><?php echo e($errors->first('password')); ?></i>
        <?php endif; ?>

        <br>
        <label>Bidang Lomba</label>
        <select name="id_bl" class="form-control">
          <?php $__currentLoopData = $bl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($bl->id); ?>"><?php echo e($bl->nama); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>
        <?php if($errors->has('id_bl')): ?>
          <i><?php echo e($errors->first('id_bl')); ?></i>
        <?php endif; ?>
        <br>

        <br>
        <label>Asal</label>
        <select name="id_asal" class="form-control">
          <?php $__currentLoopData = $asal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($asl->id); ?>"><?php echo e($asl->asal); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>
        <?php if($errors->has('id_asal')): ?>
          <i><?php echo e($errors->first('id_asal')); ?></i>
        <?php endif; ?>
        <br>

        <br>
        <label>Jabatan</label>
        <select name="jabatan" class="form-control">
          <option value="admin">Admin</option>
          <option value="user">User</option>
        </select>
        <br>
        <?php if($errors->has('jabatan')): ?>
          <i><?php echo e($errors->first('jabatan')); ?></i>
        <?php endif; ?>
        <br>
		    <button class="btn btn-warning">Buat </button>
        </form>
		  </div>
		</div>
  	</div>
   





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH C:\Users\Lenovo\Desktop\informasi_lomba\resources\views/login/create.blade.php ENDPATH**/ ?>