<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <style type="text/css">
    	.card
    	{
    		text-align: center;
    		align-items: center;
    		margin-right: auto;
    		margin-left: auto;
    		margin-bottom: auto;
    		margin-top: auto;
    		margin-top: 5%;
    	}
    	a
    	{
    		color: white;
    	}
      i
      {
        color: "lime";
      }
      table
      {
        text-align: center;
      }
    </style>

    <title>Tambah Nilai</title>
  </head>
  <body>



<div class="container">
  		
        
		  
<form action="<?php echo e(route('nilai.store')); ?>" method="post"> <?php echo csrf_field(); ?>

<button class="btn btn-primary mt-4">Tambah</button>
<table class="table table-hover table-dark table-striped mt-5">
  <thead>
    <tr>
      <th scope="col">Username</th>
      <th scope="col">Nilai</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $proses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><input type="number" name="id_user[]" value="<?php echo e($k->id_user); ?>" readonly></td>
      <td>
       <input type="hidden" name="id_bl" value="<?php echo e($k->id_bl); ?>">
       <input required type="number" name="nilai[]">
      </td>    
    </tr>
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

</div>
   





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH C:\Users\elza\Desktop\informasi_lomba\resources\views/nilai/create.blade.php ENDPATH**/ ?>