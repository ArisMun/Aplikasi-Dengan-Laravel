
<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('body'); ?>

<style type="text/css">
	.table
	{
		text-align: center;
	}
</style>


<div class="container mt-5">
<form action="<?php echo e(route('sudah.store')); ?>" method="post"><?php echo csrf_field(); ?> 
<button class="btn btn-danger mb-4">Batalkan</button>
<table class="table table-hover table-dark table-striped">
  <thead>
    <tr>
      <th scope="col">Nama User</th>
      <th scope="col">Nama Lomba</th>
      <th scope="col">Pilih</th>
    </tr>
  </thead>
  <tbody>
  	<?php $__currentLoopData = $sudah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($b->username); ?></td>
      <td><?php echo e($b->nama); ?></td>
      <td><input type="checkbox" name="id_user[]" value="<?php echo e($b->id_user); ?>"></td>    
  	</tr>
    </form>
  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>

<?php if($error = Session::get('gagal')): ?>
<h1><?php echo e($error); ?></h1>
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\elza\Desktop\informasi_lomba\resources\views/sudah/index.blade.php ENDPATH**/ ?>