
<?php $__env->startSection('title','Bidang Lomba'); ?>
<?php $__env->startSection('body'); ?>

<style type="text/css">
	.table
	{
		text-align: center;
	}
</style>


<div class="container mt-5">
<a href="<?php echo e(route('bl.create')); ?>" class="btn btn-primary mb-4">Tambah</a>
<table class="table table-hover table-dark table-striped">
  <thead>
    <tr>
      <th scope="col">Nama Lomba</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
  	<?php $__currentLoopData = $bl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($b->nama); ?></td>
      <td>
      	<form onsubmit="return confirm('Yakin ?')" action="<?php echo e(route('bl.destroy',$b->id)); ?>" method="post"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
      		<a href="<?php echo e(route('bl.edit',$b->id)); ?>" class="btn btn-primary mb-4">Ubah</a>
      		<button class="btn btn-danger">Hapus</button> 
      	</form>
      </td>    
  	</tr>
  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>

<?php if($error = Session::get('gagal')): ?>
<h1><?php echo e($error); ?></h1>
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT_SOFT_1\Desktop\informasi_lomba\resources\views/bl/index.blade.php ENDPATH**/ ?>