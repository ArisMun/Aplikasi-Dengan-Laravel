
<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('body'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\informasi_lomba\resources\views/login/home.blade.php ENDPATH**/ ?>