
<?php $__env->startSection('title','Peserta'); ?>
<?php $__env->startSection('body'); ?>

<style type="text/css">
	.table
	{
		text-align: center;
	}
</style>


<div class="container mt-5">
<form action="<?php echo e(route('peserta.store')); ?>" method="post"> <?php echo csrf_field(); ?>
<label>Bidang Lomba</label>
<select name="id_bl">
  <?php $__currentLoopData = $bl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($bl->id); ?>"><?php echo e($bl->nama); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<br><br>

<label>Asal</label>
<select name="id_asal">
  <?php $__currentLoopData = $asal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($asal->id); ?>"><?php echo e($asal->asal); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><br><br>


<button class="btn btn-danger mb-5">Daftarkan</button>
<table class="table table-hover table-dark table-striped">
  <thead>
    <tr>
      <th scope="col">Username</th>
      <th scope="col">Bidang Lomba</th>
      <th scope="col">Asal</th>
      <th scope="col">Nilai</th>
      <th scope="col">Pilih</th>
    </tr>
  </thead>
  <tbody>
  	<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($k->username); ?></td>
      <td><?php echo e($k->id_bl); ?></td>
      <td><?php echo e($k->id_asal); ?></td>
      <td><input type="number" readonly value="<?php echo e($k->nilai); ?>"></td>
      <td>
      	
        <input type="checkbox" name="pilih[]" value="<?php echo e($k->id); ?>">
      		
      </td>  
      </form>  
  	</tr>
  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT_SOFT_1\Desktop\informasi_lomba\resources\views/peserta/index.blade.php ENDPATH**/ ?>