
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('body'); ?>

<style type="text/css">
	.card
  {
    width: 50%;
    text-align: center;
    align-items: center;
  }
  label
  {
    color: white;
  }
</style>


<div class="container">
  
  <div class="card bg-danger mt-5">
    <br>
    <label><h2>Pilih Kontingen</h2></label>
    <form action="/ktg" method="post"> <?php echo csrf_field(); ?>
    <select class ="form-control mt-5 mb-5" name="bl">
      <?php $__currentLoopData = $ktg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ktg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($ktg->id); ?>"> <?php echo e($ktg->asal); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="btn btn-warning">Pilih</button>
    </form>
    <br><br>
  </div>

</div>

<div class="container mt-5">

<div class="card bg-success"><br>
<label><h3>Pilih Bidang Lomba</h3></label>
<form action="<?php echo e(route('dsh.store')); ?>" method="post"> <?php echo csrf_field(); ?>
<select class="form-control mt-5" name="id_bl">
  <?php $__currentLoopData = $bl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($bl->id); ?>"><?php echo e($bl->nama); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<button class="btn btn-primary mt-5 mb-5">Pilih</button>
</form>
</div>



</div>


<?php if($error = Session::get('gagal')): ?>
<h1><?php echo e($error); ?></h1>
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT_SOFT_1\Desktop\informasi_lomba\resources\views/dashboard/index.blade.php ENDPATH**/ ?>