
<?php $__env->startSection('title','Penilaian'); ?>
<?php $__env->startSection('body'); ?>

<style type="text/css">
	.card
  {
    width: 50%;
    text-align: center;
    align-items: center;
  }
  label
  {
    color: white;
  }
</style>


<div class="container mt-5">

<div class="card bg-success"><br>
<label>Pilih Bidang Lomba</label>
<form action="<?php echo e(route('nilai.create')); ?>">
<select class="form-control mt-5" name="id_bl">
  <?php $__currentLoopData = $bl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($bl->id); ?>"><?php echo e($bl->nama); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<button class="btn btn-primary mt-5 mb-5">Pilih</button>
</form>
</div>
</div>

<?php if($error = Session::get('gagal')): ?>
<h1><?php echo e($error); ?></h1>
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\elza\Desktop\informasi_lomba\resources\views/nilai/index.blade.php ENDPATH**/ ?>