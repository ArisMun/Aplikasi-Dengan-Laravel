<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user', function (Blueprint $table) {
            $table->id();
            $table->string('username');
            $table->string('password');
            $table->biginteger('id_bl')->unsigned()->nullable();
            $table->biginteger('id_asal')->unsigned()->nullable();
            $table->enum('jabatan',['admin','user']);
            $table->integer('nilai')->nullable();
            $table->foreign('id_bl')->references('id')->on('bidang_lomba')->onDelete('set null');
            $table->foreign('id_asal')->references('id')->on('kontingens')->onDelete('set null');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user');
    }
}
