<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<style type="text/css">
	.card
	{
		width: 100%;
	}
	.cd
	{
		margin-left: auto;
		margin-right: auto;
		text-align: center;
		align-items: center;
		background-color: blue;
		width: 40%;
	}
	input
	{
		padding: 20px;
		margin-top: 10%;
		margin-bottom: 5%;
	}
	b
	{
		color: white;
	}
</style>
<body>

	<div class="card">
		<div class="cd">
			<form action="/login" method="post"> @csrf
			<input type="text" name="username" placeholder="Enter Your Username">
			<br>
			@if($errors->has('username'))
				<b>{{ $errors->first('username') }}</b>
			@endif
			<br><br>


			<input type="password" name="password" placeholder="Enter Your Password">
			<br>
			@if($errors->has('password'))
				<b>{{ $errors->first('password') }}</b>
			@endif
			<br><br>
			<input type="submit" name="" value="Login">
			</form>
		</div>
	</div>

</body>
</html>