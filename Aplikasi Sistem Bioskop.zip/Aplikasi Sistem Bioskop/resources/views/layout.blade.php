<!DOCTYPE html>
<html>
<head>
	<title>@yield('title')</title>
</head>
<style type="text/css">
	*
	{
		padding: 0;
		margin: 0;
		font-family: "Roboto",sans-serif;
	}
	.header
	{
		display: flex;
		justify-content: space-between;
		padding: 20px;
		background-color: blue;
		color: white;
		align-items: center;
	}
	nav a
	{
		color: white;
		padding: 20px;
		font-size: 20px;
	}
	a
	{
		text-decoration: none;
	}
	.active
	{
		background-color:black;
	}
</style>
<body>

	<div class="header">
		<h1>Cinema XIXI</h1>
		<nav>
			<a href="/home" class="{{ Request::path()==='home' ? 'active' : '' }}">Home</a>
			@if(Auth::user()->role == 'admin')
			<a href="{{ route('branch.index') }}" class="{{ Request::path()==='branch' ? 'active' : '' }}">Branch</a>
			<a href="{{ route('studio.index') }}" class="{{ Request::path()==='studio' ? 'active' : '' }}">Studio</a>
			<a href="{{ route('movie.index') }}" class="{{ Request::path()==='movie' ? 'active' : '' }}">Movie</a>
			@endif
			<a href="{{ route('schedule.index') }}" class="{{ Request::path()==='schedule' ? 'active' : '' }}">Schedule</a>
			<a href="/logout">Logout</a>
		</nav>
	</div>
	@yield('body')

</body>
</html>