@extends('layout')
@section('title','Branche')
@section('body')

<style type="text/css">
	.container
	{
		width: 50%;
		margin-left: 10%;
		margin-top: 6%;
	}
	td
	{
		padding: 40px 80px;
	}
</style>


<div class="container">
	

	<a href="{{ route('branch.create') }}">Create</a>
	<table border="1">
		<thead>
			<tr>
				<td>Name</td>
				<td>Action</td>
			</tr>
		</thead>

		<tbody>
			@foreach($branch as $bc)
			<tr>
				<td>{{ $bc->name }}</td>
				<td>
					<form onsubmit="return confirm('why ?') " action="{{ route('branch.destroy',$bc->id) }}" method="post">@csrf @method("DELETE")

						<a href="{{ route('branch.edit',$bc->id) }}">Update | </a>

						<button> Delete</button>
					</form>
				</td>
			</tr>
			@endforeach
		</tbody>
	</table>

	<br><br><br>

	
		@if($berhasil = Session::get('berhasil_create'))
			<h2>{{ $berhasil }}</h2>
		@endif

		@if($berhasil = Session::get('berhasil_update'))
			<h2>{{ $berhasil }}</h2>
		@endif

		@if($berhasil = Session::get('berhasil_delete'))
			<h2>{{ $berhasil }}</h2>
		@endif


</div>



@endsection