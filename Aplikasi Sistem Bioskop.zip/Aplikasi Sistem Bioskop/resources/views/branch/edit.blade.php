<!DOCTYPE html>
<html>
<head>
	<title>Update Branch</title>
</head>
<style type="text/css">
	.card
	{
		width: 100%;
	}
	.cd
	{
		margin-left: auto;
		margin-right: auto;
		text-align: center;
		align-items: center;
		background-color: blue;
		width: 40%;
	}
	input
	{
		padding: 20px;
		margin-top: 10%;
		margin-bottom: 5%;
	}
	b
	{
		color: white;
	}
</style>
<body>

	<div class="card">
		<div class="cd">
			<form action="{{ route('branch.update',$branch->id) }}" method="post"> @csrf @method("PUT")
			<input type="text" name="name" placeholder="name" value="{{ $branch->name }}">
			<br>
			@if($errors->has('name'))
				<b>{{ $errors->first('name') }}</b>
			@endif
			<br><br>

			<input type="submit" name="" value="Update">
			</form>
		</div>
	</div>

</body>
</html>