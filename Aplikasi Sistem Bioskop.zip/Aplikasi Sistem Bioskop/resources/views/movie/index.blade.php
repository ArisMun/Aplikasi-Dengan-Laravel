@extends('layout')
@section('title','Movie')
@section('body')

<style type="text/css">
	.container
	{
		width: 50%;
		margin-left: 10%;
		margin-top: 6%;
	}
	td
	{
		padding: 40px 80px;
	}
	img
	{
		width: 100%;
		height: 30%;
	}
</style>


<div class="container">
	

	<a href="{{ route('movie.create') }}">Create</a>
	<table border="1">
		<thead>
			<tr>
				<td>Name</td>
				<td>Minute Length</td>
				<td>Picture</td>
				<td>Action</td>
			</tr>
		</thead>

		<tbody>
			@foreach($movie as $mv)
			<tr>
				<td>{{ $mv->name }}</td>
				<td>{{ $mv->minute_length }}</td>
				<td><img src="storage/img/{{ $mv->picture_url }}"></td>
				<td>
					<form onsubmit="return confirm('why ?') " action="{{ route('movie.destroy',$mv->id) }}" method="post">@csrf @method("DELETE")

						<a href="{{ route('movie.edit',$mv->id) }}">Update | </a>

						<button> Delete</button>
					</form>
				</td>
			</tr>
			@endforeach
		</tbody>
	</table>

	<br><br><br>

	
		@if($berhasil = Session::get('berhasil_create'))
			<h2>{{ $berhasil }}</h2>
		@endif

		@if($berhasil = Session::get('berhasil_update'))
			<h2>{{ $berhasil }}</h2>
		@endif

		@if($berhasil = Session::get('berhasil_delete'))
			<h2>{{ $berhasil }}</h2>
		@endif


</div>



@endsection