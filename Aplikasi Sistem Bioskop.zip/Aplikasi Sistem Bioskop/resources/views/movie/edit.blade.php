<!DOCTYPE html>
<html>
<head>
	<title>Update Movie</title>
</head>
<style type="text/css">
	.card
	{
		width: 100%;
	}
	.cd
	{
		margin-left: auto;
		margin-right: auto;
		text-align: center;
		align-items: center;
		background-color: blue;
		width: 40%;
	}
	input
	{
		padding: 20px;
		margin-top: 10%;
		margin-bottom: 5%;
	}
	b
	{
		color: white;
	}
</style>
<body>

	<div class="card">
		<div class="cd">
			<form action="{{ route('movie.update',$movie->id) }}" method="post" enctype="multipart/form-data"> @csrf @method('PUT')
			<input type="text" name="name" placeholder="name" value="{{ $movie->name }}">
			<br>
			@if($errors->has('name'))
				<b>{{ $errors->first('name') }}</b>
			@endif
			<br><br>

			<input type="number" name="minute_length" placeholder="minute_length"  value="{{ $movie->minute_length }}">
			<br>
			@if($errors->has('minute_length'))
				<b>{{ $errors->first('minute_length') }}</b>
			@endif
			<br><br>

			<input type="file" name="picture_url" placeholder="picture_url">
			<br>
			@if($errors->has('picture_url'))
				<b>{{ $errors->first('picture_url') }}</b>
			@endif
			<br><br>

			<input type="submit" name="" value="Update">
			</form>
		</div>
	</div>

</body>
</html>