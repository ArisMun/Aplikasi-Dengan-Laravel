@extends('layout')
@section('title','Studio')
@section('body')

<style type="text/css">
	.container
	{
		width: 50%;
		margin-left: 10%;
		margin-top: 6%;
	}
	td
	{
		padding: 20px 40px;
	}
</style>


<div class="container">
	

	<a href="{{ route('studio.create') }}">Create</a>
	<table border="1">
		<thead>
			<tr>
				<td>Name Studio</td>
				<td>Branch Name</td>
				<td>Basic Price</td>
				<td>Additional friday price</td>
				<td>Additional saturday price</td>
				<td>Additional sunday price</td>
				<td>Action</td>
			</tr>
		</thead>

		<tbody>
			@foreach($studio as $std)
			<tr>
				<td>{{ $std->name_std }}</td>
				<td>{{ $std->nm }}</td>
				<td>{{ $std->basic_price }}</td>
				<td>{{ $std->additional_friday_price }}</td>
				<td>{{ $std->additional_saturday_price }}</td>
				<td>{{ $std->additional_sunday_price }}</td>
				<td>
					<form onsubmit="return confirm('why ?') " action="{{ route('studio.destroy',$std->id) }}" method="post">@csrf @method("DELETE")

						<a href="{{ route('studio.edit',$std->id) }}">Update | </a>

						<button> Delete</button>
					</form>
				</td>
			</tr>
			@endforeach
		</tbody>
	</table>

	<br><br><br>

	
		@if($berhasil = Session::get('berhasil_create'))
			<h2>{{ $berhasil }}</h2>
		@endif

		@if($berhasil = Session::get('berhasil_update'))
			<h2>{{ $berhasil }}</h2>
		@endif

		@if($berhasil = Session::get('berhasil_delete'))
			<h2>{{ $berhasil }}</h2>
		@endif


</div>



@endsection