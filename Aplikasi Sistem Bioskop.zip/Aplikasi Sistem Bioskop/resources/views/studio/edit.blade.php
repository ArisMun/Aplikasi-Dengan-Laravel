<!DOCTYPE html>
<html>
<head>
	<title>Update Studio</title>
</head>
<style type="text/css">
	.card
	{
		width: 100%;
	}
	.cd
	{
		margin-left: auto;
		margin-right: auto;
		text-align: center;
		align-items: center;
		background-color: blue;
		width: 40%;
	}
	input
	{
		padding: 20px;
		margin-top: 10%;
		margin-bottom: 5%;
	}
	b
	{
		color: white;
	}
</style>
<body>

	<div class="card">
		<div class="cd">
			<form action="{{ route('studio.update',$studio->id) }}" method="post"> @csrf @method("PUT")
			<input type="text" name="name_std" placeholder="name_std" value="{{ $studio->name_std }}">
			<br>
			@if($errors->has('name_std'))
				<b>{{ $errors->first('name_std') }}</b>
			@endif
			<br><br>

			<select name="branch_id">
				@foreach($branch as $bc)
				<option value="{{ $bc['id'] }}" {{ $studio['branch_id'] == $bc['id'] ? 'selected=="selected"' : ''}}>{{ $bc['name'] }}</option>
				@endforeach
			</select>
			<br>
			@if($errors->has('branch_id'))
				<b>{{ $errors->first('branch_id') }}</b>
			@endif
			<br><br>

			<input type="number" name="basic_price" placeholder="basic_price" value="{{ $studio->basic_price }}">
			<br>
			@if($errors->has('basic_price'))
				<b>{{ $errors->first('basic_price') }}</b>
			@endif
			<br><br>

			<input type="number" name="additional_friday_price" placeholder="additional_friday_price" value="{{ $studio->additional_friday_price }}">
			<br>
			@if($errors->has('additional_friday_price'))
				<b>{{ $errors->first('additional_friday_price') }}</b>
			@endif
			<br><br>

			<input type="number" name="additional_saturday_price" placeholder="additional_saturday_price" value="{{ $studio->additional_saturday_price }}">
			<br>
			@if($errors->has('additional_saturday_price'))
				<b>{{ $errors->first('additional_saturday_price') }}</b>
			@endif
			<br><br>

			<input type="number" name="additional_sunday_price" placeholder="additional_sunday_price" value="{{ $studio->additional_sunday_price }}">
			<br>
			@if($errors->has('additional_sunday_price'))
				<b>{{ $errors->first('additional_sunday_price') }}</b>
			@endif
			<br><br>

			<input type="submit" name="" value="Update">
			</form>
		</div>
	</div>

</body>
</html>