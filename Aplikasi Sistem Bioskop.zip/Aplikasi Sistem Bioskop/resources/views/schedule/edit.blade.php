<!DOCTYPE html>
<html>
<head>
	<title>Update Schedule</title>
</head>
<style type="text/css">
	.card
	{
		width: 100%;
	}
	.cd
	{
		margin-left: auto;
		margin-right: auto;
		text-align: center;
		align-items: center;
		background-color: blue;
		width: 40%;
	}
	input
	{
		padding: 20px;
		margin-top: 10%;
		margin-bottom: 5%;
	}
	b
	{
		color: white;
	}
</style>
<body>

	<div class="card">
		<div class="cd">
			<form action="{{ route('schedule.update',$schedule->id) }}" method="post"> @csrf @method('PUT')

			<select name="movie_id">
				@foreach($movie as $mv)
				<option value="{{ $mv['id'] }}" {{ $schedule['movie_id'] ==  $mv['id'] ? 'selected=="selected"' : '' }}>{{ $mv['name'] }}</option>
				@endforeach
			</select>
			<br>
			@if($errors->has('movie_id'))
				<b>{{ $errors->first('movie_id') }}</b>
			@endif
			<br><br>

			<select name="studio_id">
				@foreach($studio as $std)
				<option value="{{ $std['id'] }}" {{ $schedule['studio_id'] ==  $std['id'] ? 'selected=="selected"' : '' }}>{{ $std['name_std'] }}</option>
				@endforeach
			</select>
			<br>
			@if($errors->has('studio_id'))
				<b>{{ $errors->first('studio_id') }}</b>
			@endif
			<br><br>

			<input type="hidden" name="waktu" value="{{ date('Y-m-d') }}">


			<input type="datetime-local" name="start" placeholder="start">
			<br>
			@if($errors->has('start'))
				<b>{{ $errors->first('start') }}</b>
			@endif
			<br><br>

			<input type="submit" name="" value="Update">
			</form>
		</div>
	</div>

</body>
</html>