@extends('layout')
@section('title','Schedule')
@section('body')

<style type="text/css">
	.container
	{
		width: 50%;
		margin-left: 10%;
		margin-top: 6%;
	}
	td
	{
		padding: 40px 80px;
	}
	img
	{
		width: 200%;
		height: 30%;
	}
	.cari
	{
		margin-top: 5%;
		margin-left: 40%;
	}
	.cari input
	{
		padding: 20px;
	}
</style>

<div class="cari">
	<form action="/cari" method="post"> @csrf


		<input type="date" name="search" placeholder="Search Date">
		
		<select name="branch">
			@foreach($branch as $br)
			<option value="{{ $br->id }}">{{ $br->name }}</option>
			@endforeach
		</select>
		<input type="submit" name="" value="Search">
	</form>

	<form action="{{ route('schedule.index') }}">
	<input type="submit" name="" value="Reset">
	</form>
</div>

<div class="container">


	
	@if(Auth::user()->role =="admin")
	<a href="{{ route('schedule.create') }}">Create</a>
	@endif
	<table border="1">
		<thead>
			<tr>
				<td>Studio Name</td>
				<td>Movie Name</td>
				<td>start</td>
				@if(Auth::user()->role =="admin")
				<td>end</td>
				@endif
				<td>price</td>
				@if(Auth::user()->role =="admin")
				<td>Action</td>
				@endif
			</tr>
		</thead>

		<tbody>
			@foreach($schedule as $sch)
			<tr>
				<td>{{ $sch->setudio }}</td>
				<td>{{ $sch->mv }}</td>
				<td>{{ $sch->start }}</td>
				@if(Auth::user()->role =="admin")
				<td>{{ $sch->end }}</td>
				@endif
				<td>{{ $sch->price }}</td>

				@if(Auth::user()->role =="admin")
				<td>
					<form onsubmit="return confirm('why ?') " action="{{ route('schedule.destroy',$sch->id) }}" method="post">@csrf @method("DELETE")

						<a href="{{ route('schedule.edit',$sch->id) }}">Update | </a>

						<button> Delete</button>
					</form>
				</td>
				@endif
			</tr>
			@endforeach
		</tbody>
	</table>

	<br><br><br>

	
		@if($berhasil = Session::get('berhasil_create'))
			<h2>{{ $berhasil }}</h2>
		@endif

		@if($berhasil = Session::get('berhasil_update'))
			<h2>{{ $berhasil }}</h2>
		@endif

		@if($berhasil = Session::get('berhasil_delete'))
			<h2>{{ $berhasil }}</h2>
		@endif


</div>



@endsection