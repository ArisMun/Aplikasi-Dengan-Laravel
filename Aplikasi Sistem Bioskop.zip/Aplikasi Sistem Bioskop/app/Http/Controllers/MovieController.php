<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\movie;
use Illuminate\Support\Facades\Storage;

class MovieController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $movie = movie::get();
        return view('movie.index',compact('movie'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('movie.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $req)
    {
        $this->validate($req,[
        'name' => 'required',
        'minute_length' => 'required',
        'picture_url' => 'required|image|mimes:jpg,png,jpeg',
    ]);


        $img = $req->file('picture_url');
        $img->storeAs('public/img',$img->hashName());

         $movie = movie::create([
            'name' =>$req->name,
            'minute_length' =>$req->minute_length,
            'picture_url' => $img->hashName(),
         ]);

          if ($movie) {
            return redirect()->route('movie.index')->with('berhasil_create',"Success Create");
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($mv)
    {
        $movie = movie::findOrFail($mv);
        return view('movie.edit',compact('movie'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $req, $movie)
    {
        $img = $req->file('picture_url'); 
        $movie = movie::findOrFail($movie);
        if ($img == '') {
        
            $movie->update([
            'name' =>$req->name,
            'minute_length' =>$req->minute_length,
         ]);    
        }

        else
        {
            Storage::disk('local')->delete('public/img/'.$movie->picture_url);

            $img->storeAs('public/img',$img->hashName());

            $movie->update([
            'name' =>$req->name,
            'minute_length' =>$req->minute_length,
            'picture_url' => $img->hashName(),
         ]);  

        }

        if ($movie) {
            return redirect()->route('movie.index')->with('berhasil_update',"Success Update");
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($mv)
    {
         $movie = movie::findOrFail($mv);
         Storage::disk('local')->delete('public/img/'.$movie->picture_url);
         $movie->delete();
        if ($movie) {
            return redirect()->route('movie.index')->with('berhasil_delete',"Success Delete");
        }
    }
}
