<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\studio;
use App\Models\movie;
use App\Models\branch;
use App\Models\schedule;
use Illuminate\Support\Facades\DB;

class ScheduleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $branch = branch::get();
        $schedule = DB::table('schedules')
        ->join('studios','schedules.studio_id','=','studios.id')
        ->join('movies','schedules.movie_id','=','movies.id')
        ->join('branches', 'branches.id','=','studios.branch_id')
        ->select('schedules.*','studios.name_std AS setudio','movies.name AS mv')
        ->get();
        return view('schedule.index',compact('schedule', 'branch'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $schedule = schedule::get();
        $movie = movie::get();
        $studio = studio::get();
        return view('schedule.create',compact('schedule','movie','studio'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $req)
    {
        $this->validate($req,[

            'movie_id' => 'required',
            'studio_id' => 'required',
            'start' => 'required',
        ]);

        $std  =studio::findOrFail($req->studio_id);
        $mv = movie::findOrFail($req->movie_id);
        $mov  =$mv->minute_length;

        $jam = floor($mov / 60)."hours";
        $menit = floor($mov % 60)."minute";
        $waktu_saat_ini = date('h:i:s',strtotime($req->start));
        $waktu_mov = "+".$jam."+".$menit;
        $waktu_akhir = date('Y-m-d h:i:s',strtotime($waktu_mov,strtotime($waktu_saat_ini)));

        $hari = date('l',strtotime($req->waktu));


        if ($hari == "Friday") {
            $schedule = schedule::create([
                'movie_id' => $req->movie_id,
                'studio_id' => $req->studio_id,
                'start' => $req->start,
                'end'=>$waktu_akhir,
                'price'=>$std->basic_price + $std->additional_friday_price,
            ]);

        }


        elseif ($hari == "Saturday") {
            $schedule = schedule::create([
                'movie_id' => $req->movie_id,
                'studio_id' => $req->studio_id,
                'start' => $req->start,
                'end'=>$waktu_akhir,
                'price'=>$std->basic_price + $std->additional_saturday_price,
            ]);
        }


        elseif ($hari == "Sunday") {
            $schedule = schedule::create([
                'movie_id' => $req->movie_id,
                'studio_id' => $req->studio_id,
                'start' => $req->start,
                'end'=>$waktu_akhir,
                'price'=>$std->basic_price + $std->additional_sunday_price,
            ]);
        }

            else{
            $schedule = schedule::create([
                'movie_id' => $req->movie_id,
                'studio_id' => $req->studio_id,
                'start' => $req->start,
                'end'=>$waktu_akhir,
                'price'=>$std->basic_price,
            ]);

        }

        if ($schedule) {
            return redirect()->route('schedule.index')->with('berhasil_create',"Success Create");
        }

    }



    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
       
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($sch)
    {
        $schedule  =schedule::findOrFail($sch);
        $movie = movie::get();
        $studio = studio::get();
        return view('schedule.edit',compact('schedule','movie','studio'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $req, $schedule)
    {
        $schedule = schedule::findOrFail($schedule);
        $waktu  = date('l',strtotime($req->waktu));
        $mov = movie::findOrFail($req->movie_id);
        $std = studio::findOrFail($req->studio_id);
        $this->validate($req,[

            'movie_id' => 'required',
            'studio_id' => 'required',
        ]);

        if ($waktu == "Friday") {
            $harga = $std->basic_price + $std->additional_friday_price;
        }
        elseif($waktu == "Saturday"){
            $harga = $std->basic_price + $std->additional_friday_price;
        }
        elseif($waktu == "Sunday"){
            $harga = $std->basic_price + $std->additional_friday_price;
        }
        else
        {
            $harga = $std->basic_price;   
        }

        if ($req->start == "") {
            $jam = floor($mov->minute_length / 60)."hours";
            $menit = floor($mov->minute_length % 60)."minute";
            $waktu_saat_ini = date('h:i:s',strtotime($schedule->start));
            $jumlah = "+".$jam."+".$menit;
            $hasil = date('Y-m-d h:i:s',strtotime($jumlah,strtotime($waktu_saat_ini)));

             $schedule->update([
            'movie_id' => $req->movie_id,
            'studio_id' => $req->studio_id,
            'start' => $schedule->start,
            'end'=> $hasil,
            'price' => $harga,
            ]);
        }

        else
        {
            $jam = floor($mov->minute_length / 60)."hours";
            $menit = floor($mov->minute_length % 60)."minute";
            $waktu_saat_ini = date('h:i:s',strtotime($req->start));
            $jumlah = "+".$jam."+".$menit;
            $hasil = date('Y-m-d h:i:s',strtotime($jumlah,strtotime($waktu_saat_ini)));
             $schedule->update([
            'movie_id' => $req->movie_id,
            'studio_id' => $req->studio_id,
            'start' => $req->start,
            'end'=> $hasil,
            'price' => $harga,
            ]);
        }

       

        if ($schedule) {
            return redirect()->route('schedule.index')->with('berhasil_update',"Success Update");
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($sch)
    {
        $schedule = schedule::findOrFail($sch)->delete();
        if ($schedule) {
            return redirect()->route('schedule.index')->with('berhasil_delete',"Success Delete");
        }
    }
}
