<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\branch;

class BranchController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $branch = branch::get();
        return view('branch.index',compact('branch'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('branch.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $req)
    {
        $this->validate($req,[

            'name' => 'required',

        ]);

        $branch = branch::create([

            'name' => $req->name,

        ]);

        if ($branch) {
            return redirect()->route('branch.index')->with('berhasil_create',"Success Create");
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($bc)
    {
        $branch = branch::findOrFail($bc);

        return view('branch.edit',compact('branch'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $req, $branch)
    {
         $this->validate($req,[

            'name' => 'required',

        ]);

         $branch = branch::findOrFail($branch);
         $branch->update([
            'name' => $req->name,
         ]);

         if ($branch) {
            return redirect()->route('branch.index')->with('berhasil_update',"Success Update");
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($bc)
    {
        $branch = branch::findOrFail($bc)->delete();
        if ($branch) {
            return redirect()->route('branch.index')->with('berhasil_delete',"Success Delete");
        }

    }
}
