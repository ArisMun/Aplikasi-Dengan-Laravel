<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\studio;
use App\Models\branch;
use Illuminate\Support\Facades\DB;



class StudioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        
        $studio = DB::table('studios')
        ->join('branches','studios.branch_id','=','branches.id')
        ->select('studios.*','branches.name AS nm')
        ->get();
        
        return view('studio.index',compact('studio'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $branch = branch::get();
        return view('studio.create',compact('branch'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $req)
    {

    
        $this->validate($req,[

            'name_std' => 'required',
            'branch_id' => 'required',
            'basic_price' => 'required|min:1|max:10.000.000',
            'additional_friday_price' => 'required|min:0|max:1.000.000',
            'additional_saturday_price' => 'required|min:0|max:1.000.000',
            'additional_sunday_price' => 'required|min:0|max:1.000.000',

        ]);

        $studio = studio::create([

            'name_std' => $req->name_std,
            'branch_id' => $req->branch_id,
            'basic_price' => $req->basic_price,
            'additional_friday_price' => $req->additional_friday_price,
            'additional_saturday_price' => $req->additional_saturday_price,
            'additional_sunday_price' => $req->additional_sunday_price,

        ]);

        if ($studio) {
            return redirect()->route('studio.index')->with('berhasil_create',"Success Create");
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($std)
    {
        $branch = branch::get();
        $studio = studio::findOrFail($std);
        return view('studio.edit',compact('studio','branch'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $req, $studio)
    {
        $this->validate($req,[

            'name_std' => 'required',
            'branch_id' => 'required',
            'basic_price' => 'required|min:1|max:10.000.000.00',
            'additional_friday_price' => 'required',
            'additional_saturday_price' => 'required',
            'additional_sunday_price' => 'required',

        ]);


        $studio = studio::findOrFail($studio);

        $studio->update([
            'name_std' => $req->name_std,
            'branch_id' => $req->branch_id,
            'basic_price' => $req->basic_price,
            'additional_friday_price' => $req->additional_friday_price,
            'additional_saturday_price' => $req->additional_saturday_price,
            'additional_sunday_price' => $req->additional_sunday_price,
        ]);

        if ($studio) {
            return redirect()->route('studio.index')->with('berhasil_update',"Success Update");
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($std)
    {
        $studio = studio::findOrFail($std)->delete();
        if ($studio) {
            return redirect()->route('studio.index')->with('berhasil_delete',"Success Delete");
        }
    }
}
