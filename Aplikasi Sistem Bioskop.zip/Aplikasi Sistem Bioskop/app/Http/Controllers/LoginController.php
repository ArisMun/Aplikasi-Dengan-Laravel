<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\branch;

class LoginController extends Controller
{
    public function index()
    {

    	if (Auth::check()) {
    		return redirect('/');
    	}

    	return view('login.index');
    }

    public function login(Request $req)
    {
    	
    	$this->validate($req,[

    		'username' => 'required',
    		'password' => 'required',

    	]);

    	$data = [

    		'username' =>$req->input('username'),
    		'password' =>$req->input('password'),

    	];

    	Auth::attempt($data);

    	if (Auth::check()) {
    		return redirect('/home');
    	}

    	else
    	{
    		return redirect('/');
    	}

    }

    public function home()
    {
        return view('login.home');
    }


     public function logout()
    {
       Auth::logout();

       return redirect('/');
    }

    public function cari(Request $req)
    {

       $branch = branch::get();
       $schedule = DB::table('schedules')
        ->join('studios','schedules.studio_id','=','studios.id')
        ->join('movies','schedules.movie_id','=','movies.id')
        ->join('branches','branches.id','=','studios.branch_id')
        ->select('schedules.*','studios.name_std AS setudio','movies.name AS mv')->where('start','like',"%".$req->search."%")->where('branches.id','like',"%".$req->branch."%")->get();
        $schedule->groupBy('price');
       return view('schedule.index',compact('schedule','branch'));
    }


}
