<!DOCTYPE html>
<html>
<head>
	<title>Update Movie</title>
</head>
<style type="text/css">
	.card
	{
		width: 100%;
	}
	.cd
	{
		margin-left: auto;
		margin-right: auto;
		text-align: center;
		align-items: center;
		background-color: blue;
		width: 40%;
	}
	input
	{
		padding: 20px;
		margin-top: 10%;
		margin-bottom: 5%;
	}
	b
	{
		color: white;
	}
</style>
<body>

	<div class="card">
		<div class="cd">
			<form action="<?php echo e(route('movie.update',$movie->id)); ?>" method="post" enctype="multipart/form-data"> <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
			<input type="text" name="name" placeholder="name" value="<?php echo e($movie->name); ?>">
			<br>
			<?php if($errors->has('name')): ?>
				<b><?php echo e($errors->first('name')); ?></b>
			<?php endif; ?>
			<br><br>

			<input type="number" name="minute_length" placeholder="minute_length"  value="<?php echo e($movie->minute_length); ?>">
			<br>
			<?php if($errors->has('minute_length')): ?>
				<b><?php echo e($errors->first('minute_length')); ?></b>
			<?php endif; ?>
			<br><br>

			<input type="file" name="picture_url" placeholder="picture_url">
			<br>
			<?php if($errors->has('picture_url')): ?>
				<b><?php echo e($errors->first('picture_url')); ?></b>
			<?php endif; ?>
			<br><br>

			<input type="submit" name="" value="Update">
			</form>
		</div>
	</div>

</body>
</html><?php /**PATH C:\Users\Lenovo\Desktop\Aplikasi Sistem Bioskop\resources\views/movie/edit.blade.php ENDPATH**/ ?>