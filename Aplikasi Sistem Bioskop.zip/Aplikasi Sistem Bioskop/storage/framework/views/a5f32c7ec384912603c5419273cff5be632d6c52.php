
<?php $__env->startSection('title','Branche'); ?>
<?php $__env->startSection('body'); ?>

<style type="text/css">
	.container
	{
		width: 50%;
		margin-left: 10%;
		margin-top: 6%;
	}
	td
	{
		padding: 40px 80px;
	}
</style>


<div class="container">
	

	<a href="<?php echo e(route('branch.create')); ?>">Create</a>
	<table border="1">
		<thead>
			<tr>
				<td>Name</td>
				<td>Action</td>
			</tr>
		</thead>

		<tbody>
			<?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($bc->name); ?></td>
				<td>
					<form onsubmit="return confirm('why ?') " action="<?php echo e(route('branch.destroy',$bc->id)); ?>" method="post"><?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?>

						<a href="<?php echo e(route('branch.edit',$bc->id)); ?>">Update | </a>

						<button> Delete</button>
					</form>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

	<br><br><br>

	
		<?php if($berhasil = Session::get('berhasil_create')): ?>
			<h2><?php echo e($berhasil); ?></h2>
		<?php endif; ?>

		<?php if($berhasil = Session::get('berhasil_update')): ?>
			<h2><?php echo e($berhasil); ?></h2>
		<?php endif; ?>

		<?php if($berhasil = Session::get('berhasil_delete')): ?>
			<h2><?php echo e($berhasil); ?></h2>
		<?php endif; ?>


</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\Aplikasi Sistem Bioskop\resources\views/branch/index.blade.php ENDPATH**/ ?>