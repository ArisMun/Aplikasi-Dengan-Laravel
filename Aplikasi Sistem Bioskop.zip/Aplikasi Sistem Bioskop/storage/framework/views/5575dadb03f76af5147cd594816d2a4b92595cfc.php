<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<style type="text/css">
	.card
	{
		width: 100%;
	}
	.cd
	{
		margin-left: auto;
		margin-right: auto;
		text-align: center;
		align-items: center;
		background-color: blue;
		width: 40%;
	}
	input
	{
		padding: 20px;
		margin-top: 10%;
		margin-bottom: 5%;
	}
	b
	{
		color: white;
	}
</style>
<body>

	<div class="card">
		<div class="cd">
			<form action="/login" method="post"> <?php echo csrf_field(); ?>
			<input type="text" name="username" placeholder="Enter Your Username">
			<br>
			<?php if($errors->has('username')): ?>
				<b><?php echo e($errors->first('username')); ?></b>
			<?php endif; ?>
			<br><br>


			<input type="password" name="password" placeholder="Enter Your Password">
			<br>
			<?php if($errors->has('password')): ?>
				<b><?php echo e($errors->first('password')); ?></b>
			<?php endif; ?>
			<br><br>
			<input type="submit" name="" value="Login">
			</form>
		</div>
	</div>

</body>
</html><?php /**PATH C:\Users\LABE_19\Desktop\Aplikasi Sistem Bioskop\resources\views/login/index.blade.php ENDPATH**/ ?>