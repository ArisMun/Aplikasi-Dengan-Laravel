<!DOCTYPE html>
<html>
<head>
	<title>Create Branch</title>
</head>
<style type="text/css">
	.card
	{
		width: 100%;
	}
	.cd
	{
		margin-left: auto;
		margin-right: auto;
		text-align: center;
		align-items: center;
		background-color: blue;
		width: 40%;
	}
	input
	{
		padding: 20px;
		margin-top: 10%;
		margin-bottom: 5%;
	}
	b
	{
		color: white;
	}
</style>
<body>

	<div class="card">
		<div class="cd">
			<form action="<?php echo e(route('branch.store')); ?>" method="post"> <?php echo csrf_field(); ?>
			<input type="text" name="name" placeholder="name">
			<br>
			<?php if($errors->has('name')): ?>
				<b><?php echo e($errors->first('name')); ?></b>
			<?php endif; ?>
			<br><br>

			<input type="submit" name="" value="Create">
			</form>
		</div>
	</div>

</body>
</html><?php /**PATH C:\Users\Lenovo\Desktop\Aplikasi Sistem Bioskop\resources\views/branch/create.blade.php ENDPATH**/ ?>