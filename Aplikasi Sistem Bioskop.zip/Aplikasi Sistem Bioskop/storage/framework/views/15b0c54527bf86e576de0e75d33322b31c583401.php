
<?php $__env->startSection('title','Studio'); ?>
<?php $__env->startSection('body'); ?>

<style type="text/css">
	.container
	{
		width: 50%;
		margin-left: 10%;
		margin-top: 6%;
	}
	td
	{
		padding: 20px 40px;
	}
</style>


<div class="container">
	

	<a href="<?php echo e(route('studio.create')); ?>">Create</a>
	<table border="1">
		<thead>
			<tr>
				<td>Name</td>
				<td>Branch Id</td>
				<td>Basic Price</td>
				<td>Additional friday price</td>
				<td>Additional saturday price</td>
				<td>Additional sunday price</td>
				<td>Action</td>
			</tr>
		</thead>

		<tbody>
			<?php $__currentLoopData = $studio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $std): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($std->name); ?></td>
				<td><?php echo e($std->branch_id); ?></td>
				<td><?php echo e($std->basic_price); ?></td>
				<td><?php echo e($std->additional_friday_price); ?></td>
				<td><?php echo e($std->additional_saturday_price); ?></td>
				<td><?php echo e($std->additional_sunday_price); ?></td>
				<td>
					<form onsubmit="return confirm('why ?') " action="<?php echo e(route('studio.destroy',$std->id)); ?>" method="post"><?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?>

						<a href="<?php echo e(route('studio.edit',$std->id)); ?>">Update | </a>

						<button> Delete</button>
					</form>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

	<br><br><br>

	
		<?php if($berhasil = Session::get('berhasil_create')): ?>
			<h2><?php echo e($berhasil); ?></h2>
		<?php endif; ?>

		<?php if($berhasil = Session::get('berhasil_update')): ?>
			<h2><?php echo e($berhasil); ?></h2>
		<?php endif; ?>

		<?php if($berhasil = Session::get('berhasil_delete')): ?>
			<h2><?php echo e($berhasil); ?></h2>
		<?php endif; ?>


</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\Aplikasi Sistem Bioskop\resources\views/studio/index.blade.php ENDPATH**/ ?>