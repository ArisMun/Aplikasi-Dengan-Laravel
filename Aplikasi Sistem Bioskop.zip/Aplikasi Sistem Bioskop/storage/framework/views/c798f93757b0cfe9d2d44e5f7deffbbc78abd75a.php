<!DOCTYPE html>
<html>
<head>
	<title>Create Schedule</title>
</head>
<style type="text/css">
	.card
	{
		width: 100%;
	}
	.cd
	{
		margin-left: auto;
		margin-right: auto;
		text-align: center;
		align-items: center;
		background-color: blue;
		width: 40%;
	}
	input
	{
		padding: 20px;
		margin-top: 10%;
		margin-bottom: 5%;
	}
	b
	{
		color: white;
	}
</style>
<body>

	<div class="card">
		<div class="cd">
			<form action="<?php echo e(route('schedule.store')); ?>" method="post"> <?php echo csrf_field(); ?>

			<select name="movie_id">
				<?php $__currentLoopData = $movie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($mv->id); ?>"><?php echo e($mv->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
			<br>
			<?php if($errors->has('movie_id')): ?>
				<b><?php echo e($errors->first('movie_id')); ?></b>
			<?php endif; ?>
			<br><br>

			<select name="studio_id">
				<?php $__currentLoopData = $studio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $std): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($std->id); ?>"><?php echo e($std->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
			<br>
			<?php if($errors->has('studio_id')): ?>
				<b><?php echo e($errors->first('studio_id')); ?></b>
			<?php endif; ?>
			<br><br>

			<input type="hidden" name="waktu" value="<?php echo e(date('Y-m-d')); ?>">


			<input type="datetime-local" name="start" placeholder="start">
			<br>
			<?php if($errors->has('start')): ?>
				<b><?php echo e($errors->first('start')); ?></b>
			<?php endif; ?>
			<br><br>

			<input type="submit" name="" value="Create">
			</form>
		</div>
	</div>

</body>
</html><?php /**PATH C:\Users\Lenovo\Desktop\Aplikasi Sistem Bioskop\resources\views/schedule/create.blade.php ENDPATH**/ ?>