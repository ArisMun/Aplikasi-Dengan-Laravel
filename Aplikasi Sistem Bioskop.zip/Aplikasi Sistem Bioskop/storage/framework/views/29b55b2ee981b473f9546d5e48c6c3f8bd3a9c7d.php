<!DOCTYPE html>
<html>
<head>
	<title>Create Studio</title>
</head>
<style type="text/css">
	.card
	{
		width: 100%;
	}
	.cd
	{
		margin-left: auto;
		margin-right: auto;
		text-align: center;
		align-items: center;
		background-color: blue;
		width: 40%;
	}
	input
	{
		padding: 20px;
		margin-top: 10%;
		margin-bottom: 5%;
	}
	b
	{
		color: white;
	}
</style>
<body>

	<div class="card">
		<div class="cd">
			<form action="<?php echo e(route('studio.store')); ?>" method="post"> <?php echo csrf_field(); ?>
			<input type="text" name="name" placeholder="name">
			<br>
			<?php if($errors->has('name')): ?>
				<b><?php echo e($errors->first('name')); ?></b>
			<?php endif; ?>
			<br><br>

			<select name="branch_id">
				<?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($bc->id); ?>"><?php echo e($bc->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
			<br>
			<?php if($errors->has('branch_id')): ?>
				<b><?php echo e($errors->first('branch_id')); ?></b>
			<?php endif; ?>
			<br><br>

			<input type="number" name="basic_price" placeholder="basic_price">
			<br>
			<?php if($errors->has('basic_price')): ?>
				<b><?php echo e($errors->first('basic_price')); ?></b>
			<?php endif; ?>
			<br><br>

			<input type="number" name="additional_friday_price" placeholder="additional_friday_price">
			<br>
			<?php if($errors->has('additional_friday_price')): ?>
				<b><?php echo e($errors->first('additional_friday_price')); ?></b>
			<?php endif; ?>
			<br><br>

			<input type="number" name="additional_saturday_price" placeholder="additional_saturday_price">
			<br>
			<?php if($errors->has('additional_saturday_price')): ?>
				<b><?php echo e($errors->first('additional_saturday_price')); ?></b>
			<?php endif; ?>
			<br><br>

			<input type="number" name="additional_sunday_price" placeholder="additional_sunday_price">
			<br>
			<?php if($errors->has('additional_sunday_price')): ?>
				<b><?php echo e($errors->first('additional_sunday_price')); ?></b>
			<?php endif; ?>
			<br><br>

			<input type="submit" name="" value="Create">
			</form>
		</div>
	</div>

</body>
</html><?php /**PATH C:\Users\Lenovo\Desktop\Aplikasi Sistem Bioskop\resources\views/studio/create.blade.php ENDPATH**/ ?>