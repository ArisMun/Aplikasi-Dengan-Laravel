<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<style type="text/css">
	*
	{
		padding: 0;
		margin: 0;
		font-family: "Roboto",sans-serif;
	}
	.header
	{
		display: flex;
		justify-content: space-between;
		padding: 20px;
		background-color: blue;
		color: white;
		align-items: center;
	}
	nav a
	{
		color: white;
		padding: 20px;
		font-size: 20px;
	}
	a
	{
		text-decoration: none;
	}
	.active
	{
		background-color:black;
	}
</style>
<body>

	<div class="header">
		<h1>Cinema XIXI</h1>
		<nav>
			<a href="/home" class="<?php echo e(Request::path()==='home' ? 'active' : ''); ?>">Home</a>
			<?php if(Auth::user()->role == 'admin'): ?>
			<a href="<?php echo e(route('branch.index')); ?>" class="<?php echo e(Request::path()==='branch' ? 'active' : ''); ?>">Branch</a>
			<a href="<?php echo e(route('studio.index')); ?>" class="<?php echo e(Request::path()==='studio' ? 'active' : ''); ?>">Studio</a>
			<a href="<?php echo e(route('movie.index')); ?>" class="<?php echo e(Request::path()==='movie' ? 'active' : ''); ?>">Movie</a>
			<?php endif; ?>
			<a href="<?php echo e(route('schedule.index')); ?>" class="<?php echo e(Request::path()==='schedule' ? 'active' : ''); ?>">Schedule</a>
			<a href="/logout">Logout</a>
		</nav>
	</div>
	<?php echo $__env->yieldContent('body'); ?>

</body>
</html><?php /**PATH C:\Users\LABE_19\Desktop\Aplikasi Sistem Bioskop\resources\views/layout.blade.php ENDPATH**/ ?>