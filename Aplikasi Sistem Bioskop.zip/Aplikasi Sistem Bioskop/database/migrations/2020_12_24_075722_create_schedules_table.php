<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSchedulesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('schedules', function (Blueprint $table) {
            $table->integer('id',10)->unsigned();
            $table->integer('movie_id')->unsigned()->nullable();
            $table->integer('studio_id')->unsigned()->nullable();
            $table->dateTime('start');
            $table->dateTime('end');
            $table->decimal('price',13,2);
            $table->foreign('movie_id')->references('id')->on('movies')->onDelete('set null');
            $table->foreign('studio_id')->references('id')->on('studios')->onDelete('set null');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('schedules');
    }
}
